import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../core/network/api.state.dart';
import '../../core/utils/preety.dio.dart';
import '../models/jobListModel.dart';


final jobListingsProvider = FutureProvider.autoDispose<JobListModel>((ref) async {
  final dio = await createDio();
  final service = APIStateNetwork(dio);




  try {
    final response = await service.getJobListings(
        "Future Systems",
        "Sallieshire",
        "Contract",
        "",
        "",
        "",
        1,
        10
    );

    if (response.response.statusCode == 200) {
      return response.data;
    } else {
      Fluttertoast.showToast(msg: "Search Failed: ${response.response.statusCode}");
      throw Exception("Search failed");
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Search API Error");
    throw Exception("API Error: $e");
  }
  // if (response.response.statusCode != 200) {
  //   Fluttertoast.showToast(msg: "Failed to load job listings");
  //   throw Exception('Failed to load job listings');
  // }
  // return response.data;
});

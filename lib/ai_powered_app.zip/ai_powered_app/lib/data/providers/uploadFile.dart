import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hive/hive.dart';
import 'package:http_parser/http_parser.dart';
import '../../core/network/api.state.dart';
import '../../core/utils/preety.dio.dart';
import '../../screen/matrimony.screen/location.lifeStyle.page.dart';
/*

final uploadProfilePhotoProvider = FutureProvider.family.autoDispose<void, File>((ref, file) async {
  final box = await Hive.openBox('userdata');
  final userId = box.get('user_id');
  final token = box.get('token');

  print('User ID: $userId');
  print('Token: $token');

  if (userId == null || token == null) {
    throw Exception('Missing user ID or token');
  }

  final dio = await createDio();
  final service = APIStateNetwork(dio);

  final fileName = file.path.split('/').last;

  final multipartFile = await MultipartFile.fromFile(
    file.path,
    filename: fileName,
    contentType: MediaType("image", "jpeg"), // or adjust to your type
  );

  final response = await service.uploadProfilePhoto(
    [multipartFile],                   // photo[] as list
    userId.toString(),                // user_id as query param
    'Bearer $token',                  // token in header
  );

  if (response.response.statusCode != 201) {
    Fluttertoast.showToast(msg: "Photo upload failed");
    // throw Exception("Photo upload failed");
    Navigator.push(context, MaterialPageRoute(builder: (context)=>LocationLifestylePage()));

  }

  Fluttertoast.showToast(msg: "Photo uploaded successfully");
});
*/



final uploadProfilePhotoProvider = FutureProvider.family.autoDispose<void, File>((ref, file) async {
  final box = await Hive.openBox('userdata');
  final userId = box.get('user_id');
  final token = box.get('token');

  if (userId == null || token == null) {
    throw Exception('Missing user ID or token');
  }

  final dio = await createDio();
  final service = APIStateNetwork(dio);

  final fileName = file.path.split('/').last;

  final multipartFile = await MultipartFile.fromFile(
    file.path,
    filename: fileName,
    contentType: MediaType("image", "jpeg"),
  );

  final response = await service.uploadProfilePhoto(
    [multipartFile],
    userId.toString(),

  );

  if (response.response.statusCode != 201) {
    throw Exception("Photo upload failed");
  }

  // Upload succeeded, return void
});

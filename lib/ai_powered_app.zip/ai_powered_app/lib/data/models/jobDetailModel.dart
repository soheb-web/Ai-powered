// To parse this JSON data, do
//
//     final jobDetailModel = jobDetailModelFromJson(jsonString);

import 'dart:convert';

JobDetailModel jobDetailModelFromJson(String str) => JobDetailModel.fromJson(json.decode(str));

String jobDetailModelToJson(JobDetailModel data) => json.encode(data.toJson());

class JobDetailModel {
  bool status;
  String message;
  Data data;

  JobDetailModel({
    required this.status,
    required this.message,
    required this.data,
  });

  factory JobDetailModel.fromJson(Map<String, dynamic> json) => JobDetailModel(
    status: json["status"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data.toJson(),
  };
}

class Data {
  int id;
  String title;
  String company;
  String description;
  String requirements;
  String location;
  String salaryRange;
  String employmentType;
  String status;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic minExperience;
  dynamic maxExperience;
  dynamic salaryMin;
  dynamic salaryMax;
  DateTime postedDate;
  dynamic applicationDeadline;
  dynamic employerId;

  Data({
    required this.id,
    required this.title,
    required this.company,
    required this.description,
    required this.requirements,
    required this.location,
    required this.salaryRange,
    required this.employmentType,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.minExperience,
    required this.maxExperience,
    required this.salaryMin,
    required this.salaryMax,
    required this.postedDate,
    required this.applicationDeadline,
    required this.employerId,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    title: json["title"],
    company: json["company"],
    description: json["description"],
    requirements: json["requirements"],
    location: json["location"],
    salaryRange: json["salary_range"],
    employmentType: json["employment_type"],
    status: json["status"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    minExperience: json["min_experience"],
    maxExperience: json["max_experience"],
    salaryMin: json["salary_min"],
    salaryMax: json["salary_max"],
    postedDate: DateTime.parse(json["posted_date"]),
    applicationDeadline: json["application_deadline"],
    employerId: json["employer_id"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "company": company,
    "description": description,
    "requirements": requirements,
    "location": location,
    "salary_range": salaryRange,
    "employment_type": employmentType,
    "status": status,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "min_experience": minExperience,
    "max_experience": maxExperience,
    "salary_min": salaryMin,
    "salary_max": salaryMax,
    "posted_date": postedDate.toIso8601String(),
    "application_deadline": applicationDeadline,
    "employer_id": employerId,
  };
}

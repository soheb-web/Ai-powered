// To parse this JSON data, do
//
//     final profileBasedModel = profileBasedModelFromJson(jsonString);

import 'dart:convert';

ProfileBasedModel profileBasedModelFromJson(String str) => ProfileBasedModel.fromJson(json.decode(str));

String profileBasedModelToJson(ProfileBasedModel data) => json.encode(data.toJson());

class ProfileBasedModel {
  bool status;
  List<Result> results;
  int totalResults;
  int page;
  int limit;

  ProfileBasedModel({
    required this.status,
    required this.results,
    required this.totalResults,
    required this.page,
    required this.limit,
  });

  factory ProfileBasedModel.fromJson(Map<String, dynamic> json) => ProfileBasedModel(
    status: json["status"],
    results: List<Result>.from(json["results"].map((x) => Result.fromJson(x))),
    totalResults: json["total_results"],
    page: json["page"],
    limit: json["limit"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "results": List<dynamic>.from(results.map((x) => x.toJson())),
    "total_results": totalResults,
    "page": page,
    "limit": limit,
  };
}

class Result {
  dynamic userId;
  String name;
  dynamic age;
  String? location;
  String? education;
  String? occupation;
  String? photoThumbnail;

  Result({
    required this.userId,
    required this.name,
    required this.age,
    required this.location,
    required this.education,
    required this.occupation,
    required this.photoThumbnail,
  });

  factory Result.fromJson(Map<String, dynamic> json) => Result(
    userId: json["user_id"],
    name: json["name"],
    age: json["age"],
    location: json["location"],
    education: json["education"],
    occupation: json["occupation"],
    photoThumbnail: json["photo_thumbnail"],
  );

  Map<String, dynamic> toJson() => {
    "user_id": userId,
    "name": name,
    "age": age,
    "location": location,
    "education": education,
    "occupation": occupation,
    "photo_thumbnail": photoThumbnail,
  };
}

// To parse this JSON data, do
//
//     final matchProfileModel = matchProfileModelFromJson(jsonString);

import 'dart:convert';

MatchProfileModel matchProfileModelFromJson(String str) => MatchProfileModel.fromJson(json.decode(str));

String matchProfileModelToJson(MatchProfileModel data) => json.encode(data.toJson());

class MatchProfileModel {
  bool status;
  List<Match> matches;

  MatchProfileModel({
    required this.status,
    required this.matches,
  });

  factory MatchProfileModel.fromJson(Map<String, dynamic> json) => MatchProfileModel(
    status: json["status"],
    matches: List<Match>.from(json["matches"].map((x) => Match.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "matches": List<dynamic>.from(matches.map((x) => x.toJson())),
  };
}

class Match {
  int userId;
  String name;
  dynamic age;
  String? location;
  String? photoThumbnail;
  String status;

  Match({
    required this.userId,
    required this.name,
    required this.age,
    required this.location,
    required this.photoThumbnail,
    required this.status,
  });

  factory Match.fromJson(Map<String, dynamic> json) => Match(
    userId: json["user_id"],
    name: json["name"],
    age: json["age"],
    location: json["location"],
    photoThumbnail: json["photo_thumbnail"],
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "user_id": userId,
    "name": name,
    "age": age,
    "location": location,
    "photo_thumbnail": photoThumbnail,
    "status": status,
  };
}

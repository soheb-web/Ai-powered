import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import '../../data/models/MatchProfileModel.dart';
import '../../data/models/employerResisterRequestModel.dart';
import '../../data/models/jobDetailModel.dart';
import '../../data/models/jobListModel.dart';
import '../../data/models/login.body.dart';
import '../../data/models/profileBasedModel.dart';
import '../../data/models/profileModel.dart';
import '../../data/models/register.req.model.dart';
import '../../screen/jobs.screen/myJobScreen.dart';
import 'package:retrofit/http.dart'; // already imported
part 'api.state.g.dart';


@RestApi(baseUrl: 'https://aipowered.globallywebsolutions.com/api')
abstract class APIStateNetwork {
  factory APIStateNetwork(Dio dio, ) = _APIStateNetwork;



  @POST('/matrimony/auth/login')
  Future<HttpResponse<dynamic>> login(@Body() LoginBody body);


  @POST('/jobs/auth/login')
  Future<HttpResponse<dynamic>> jobsLogin(@Body() LoginBody body);


 @POST('/realestate/auth/login')
  Future<HttpResponse<dynamic>> realStateLogin(@Body() LoginBody body);




  @POST('/matrimony/auth/register')
  Future<HttpResponse<dynamic>> register(@Body() RegisterRequest body);




  @GET('/matrimony/profile/')
  Future<HttpResponse<ProfileModel>> fetchProfile(
      @Query("user_id") String userId,
      );





  @POST('/matrimony/profile/upload-photo')
  @MultiPart()
  Future<HttpResponse<dynamic>> uploadProfilePhoto(
      @Part(name: 'photo[]') List<MultipartFile> photos,
      @Query('user_id') String userId,
      );




  @POST('/matrimony/profile-update')
  Future<HttpResponse<dynamic>> updateProfile(
      @Query("user_id") String userId,
      @Body() Map<String, dynamic> body,
      );




  @GET('/matrimony/search')
  Future<HttpResponse<ProfileBasedModel>> searchProfileBasedQuery(
      @Query('user_id') String userId,
      );





  @POST('/matrimony/match')
  Future<HttpResponse<dynamic>> matchUser(
      @Query('user_id') String userId,
      @Body() Map<String, dynamic> body,
      );


  @GET('/matrimony/matches')
  Future<HttpResponse<MatchProfileModel>> getMatches(
      @Query('user_id') String userId,
      );


////////////////////////////////////////////////////////////////////////////





 @POST('/realestate/auth/register')
 Future<HttpResponse<dynamic>> registerRealState(@Body() RegisterRequest body);
 // Future<HttpResponse<dynamic>> registerRealState(
 //     @Part(name: 'name') String name,
 //     @Part(name: 'email') String email,
 //     @Part(name: 'password') String password,
 //     @Part(name: 'phone') String phone,
 //     @Part(name: 'role') String role,
 //     // @Part(name: 'resume') MultipartFile resumeFile,
 //     );


 @GET('/jobs/listings')
  Future<HttpResponse<JobListModel>> getJobListings(
      @Query('keyword') String keyword,
      @Query('location') String location,
      @Query('job_type') String jobType,
      @Query('experience_min') String? experienceMin,
      @Query('experience_max') String? experienceMax,
      @Query('industry') String? industry,
      @Query('page') int page,
      @Query('limit') int limit,
      );


  @GET('/jobs/listing')
  Future<HttpResponse<JobDetailModel>> getJobDetails(
      @Query('job_id') String jobId,
      );


  @POST('/jobs/apply')
  Future<HttpResponse<dynamic>> applyForJob(
      @Body() Map<String, dynamic> body,
      );


  @POST('/jobs/employer/register')
  Future<HttpResponse<dynamic>> resisterEmployer(@Body() EmployerRegisterRequestBody body);



  @GET('/jobs/my-applications')
  Future<HttpResponse<JobApplicationListModel>> getMyJobApplications(
      @Query('user_id') String userId,
      );




}






import 'dart:io';
import 'package:ai_powered_app/screen/matrimony.screen/location.lifeStyle.page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../data/providers/uploadFile.dart';

class UploadPhotoPage extends ConsumerStatefulWidget {
  const UploadPhotoPage({super.key});

  @override
  ConsumerState<UploadPhotoPage> createState() => _UploadPhotoPageState();
}

class _UploadPhotoPageState extends ConsumerState<UploadPhotoPage> {
  File? image;
  final picker = ImagePicker();

  Future pickImageFromCamera() async {
    var status = await Permission.camera.request();
    if (status.isGranted) {
      final pickedFile = await picker.pickImage(source: ImageSource.camera);
      if (pickedFile != null) {
        setState(() {
          image = File(pickedFile.path);
        });
      }
    } else {
      Fluttertoast.showToast(msg: "Camera permission denied");
    }
  }

  Future pickImageFromGallery() async {
    var status = await Permission.storage.request(); // storage permission for gallery
    if (status.isGranted) {
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        setState(() {
          image = File(pickedFile.path);
        });
      }
    } else {
      Fluttertoast.showToast(msg: "Gallery permission denied");
    }
  }

  Future showImagePicker() async {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoActionSheet(
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              pickImageFromCamera();
            },
            child: const Text("Camera"),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              pickImageFromGallery();
            },
            child: const Text("Gallery"),
          ),
        ],
      ),
    );
  }


  void uploadAndContinue() async {
    if (image == null) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const LocationLifestylePage()),
      );
      // Fluttertoast.showToast(msg: "Please upload an image first");
      return;
    }

    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return const Center(
          child: CircularProgressIndicator(), // or CupertinoActivityIndicator()
        );
      },
    );

    try {
      await ref.read(uploadProfilePhotoProvider(image!).future);

      Navigator.pop(context); // Close the loader
      Fluttertoast.showToast(msg: "Photo uploaded successfully");

      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const LocationLifestylePage()),
      );
    } catch (e) {
      Navigator.pop(context); // Close the loader
      Fluttertoast.showToast(msg: "Upload failed: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF6F8),
      appBar: AppBar(backgroundColor: const Color(0xFFFDF6F8)),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 15.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Upload a Profile Photo",
              style: GoogleFonts.gothicA1(
                fontSize: 30.sp,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF030016),
                letterSpacing: -1,
              ),
            ),
            Text(
              "A good photo helps build trust and gets better responses.",
              style: GoogleFonts.gothicA1(
                fontSize: 16.sp,
                fontWeight: FontWeight.w400,
                color: const Color(0xFF9A97AE),
              ),
            ),
            SizedBox(height: 25.h),
            GestureDetector(
              onTap: showImagePicker,
              child: Container(
                width: double.infinity,
                height: 134.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15.r),
                  border: Border.all(color: const Color(0xFFDADADA), width: 1.5.w),
                ),
                child: image == null
                    ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.file_upload_outlined, color: const Color(0xFFFE9F0F), size: 30.sp),
                    Text(
                      "Upload your profile photo",
                      style: GoogleFonts.gothicA1(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w500,
                        color: const Color(0xFF9A97AE),
                      ),
                    ),
                  ],
                )
                    : ClipRRect(
                  borderRadius: BorderRadius.circular(15.r),
                  child: Image.file(image!, fit: BoxFit.cover, width: double.infinity),
                ),
              ),
            ),
            SizedBox(height: 25.h),
            GestureDetector(
              onTap: uploadAndContinue,
              child: Container(
                width: double.infinity,
                height: 53.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15.r),
                  color: const Color(0xFFFE9F0F),
                ),
                child: Center(
                  child: Text(
                    "Continue",
                    style: GoogleFonts.gothicA1(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

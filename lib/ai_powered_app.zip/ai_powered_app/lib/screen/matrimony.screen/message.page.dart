import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import 'chatScreen.dart';

class MessagePage extends StatefulWidget {
  const MessagePage({super.key});

  @override
  State<MessagePage> createState() => _MessagePageState();
}

class _MessagePageState extends State<MessagePage> {
  // Dummy message data
  final List<Map<String, String>> messages = [
    {
      "name": "Aisha Khan",
      "lastMessage": "Hi, how are you?",
      "imageUrl": "https://via.placeholder.com/150"
    },
    {
      "name": "Rajeev Sharma",
      "lastMessage": "Let's catch up tomorrow.",
      "imageUrl": "https://via.placeholder.com/150"
    },
    {
      "name": "Emily",
      "lastMessage": "Thank you!",
      "imageUrl": "https://via.placeholder.com/150"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFDF6F8),
    appBar:   AppBar(
      backgroundColor:  Color(0xFFFDF6F8),
        centerTitle: true,
        title: Text(
          "Messages",
          style: GoogleFonts.gothicA1(
            fontSize: 20.sp,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF030016),
            letterSpacing: -1,
          ),
          // style: TextStyle( fontSize: 15,),
        ),
        leading: Icon(Icons.add,color: Colors.white,)
      ),

      body: ListView.builder(
        itemCount: messages.length,
        itemBuilder: (context, index) {
          final msg = messages[index];
          return
            Column(children: [

            ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(msg['imageUrl']!),
            ),
            title: Text(msg['name']!),
            subtitle: Text(msg['lastMessage']!),
            onTap: () {
             Navigator.push(context, MaterialPageRoute(builder: (context)=>ChatScreen()));
            },




              trailing: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisSize: MainAxisSize.min,
                children: [
                // Top time
                Text(
                "10:30", // Format your time here as needed
                  style: GoogleFonts.gothicA1(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF030016),
                    letterSpacing: -1,
                  ),
              ),
              SizedBox(height: 4), // Space between time and notification icon
              // Bottom notification icon
              // if (hasNotification)
          Icon(
            Icons.notifications,
            size: 20,
            color: const Color(0xFFFE9F0F),
          )
          // );
        ]
      ),
    ),

Padding(padding: EdgeInsets.only(left: 10,right: 10),
child:
    Divider()
)

            ]); }

    ));
  }

}


import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';



class UserViewedProfilesScreen extends StatelessWidget {
  const UserViewedProfilesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff8f8f8),

      body: Column(
        children: [
          SizedBox(height: 10.h,),
          _buildSearchFilter(),
          Padding(
            padding:  EdgeInsets.all(24.w, ),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Viewed Profiles (7)",
                style: GoogleFonts.gothicA1(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFFFE9F0F),
                  letterSpacing: -1,
                ),
              ),
            ),
          ),
           Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w, ),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "The profiles viewed by you are displayed here.\nLocation: All",
              ),
            ),
          ),
           SizedBox(height: 10.h),
          Expanded(
            child: ListView(
              padding:  EdgeInsets.all(12.w),
              children: const [
                ProfileCard(
                  name: 'kavitha',
                  age: '26yrs',
                  height: '5ft 4in',
                  location: 'Tamil Nadu',
                  profileId: 'GG551900',
                  isPhotoLocked: false,
                  imagePath: 'https://i.imgur.com/QCNbOAo.png',
                ),

              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchFilter() {
    return Container(
      color:  Color(0xFFFDF6F8),
      padding:  EdgeInsets.all(12.w),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                contentPadding:
                 EdgeInsets.symmetric(vertical: 0.w, horizontal: 12.w),
                hintText: 'Search',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.r)),
              ),
            ),
          ),
           SizedBox(width: 10.w),
          Container(
            decoration: BoxDecoration(
              color: Colors.pink.shade100,
              borderRadius: BorderRadius.circular(10.r),
            ),
            child:  Padding(
              padding: EdgeInsets.all(10.w),
              child: Icon(Icons.filter_list,   color: const Color(0xFFFE9F0F),),
            ),
          )
        ],
      ),
    );
  }
}
class ProfileCard extends StatelessWidget {
  final String name, age, height, location, profileId;
  final bool isPhotoLocked;
  final String? imagePath;

  const ProfileCard({
    super.key,
    required this.name,
    required this.age,
    required this.height,
    required this.location,
    required this.profileId,
    required this.isPhotoLocked,
    this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return
      Card(elevation: 1, color:  Color(0xFFFDF6F8), child:

      Padding(padding:  EdgeInsets.all(12.w),
        child: Row(
          children: [
            _buildProfileImage(),
             SizedBox(width: 12.w),
            Expanded(child: _buildProfileDetails()),
          ],
        )));
  }

  Widget _buildProfileImage() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child:

         Image.network(
        imagePath!,
        width: 75.w,
        height: 75.w,
        fit: BoxFit.cover,
      ),
    );
  }

  Widget _buildProfileDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(name,
            style:  TextStyle(
                fontSize: 16.sp, fontWeight: FontWeight.bold, color: Colors.black)),
        Text("Age / Height : $age , $height",  style:  TextStyle(
            fontSize: 12.sp, fontWeight: FontWeight.bold, color: Colors.grey)),
        Text(location, style:  TextStyle(
            fontSize: 12.sp,   color: Colors.grey)),
         SizedBox(height: 4.h),

        Row(

          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
          Text(profileId, style: const TextStyle(  color: const Color(0xFFFE9F0F),)),
          SizedBox(height: 8.h),
          Row(
            children: [
              const Icon(Icons.call,  color: const Color(0xFFFE9F0F),),
              SizedBox(width: 6.w),
              const Icon(Icons.settings,  color: const Color(0xFFFE9F0F),),
              SizedBox(width: 6.w),
              const Icon(Icons.favorite_border,  color: const Color(0xFFFE9F0F),),
            ],
          ),

        ],),


         SizedBox(height: 8.h),
        Row(
          children: [
            Expanded(
              child:ElevatedButton(

                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  backgroundColor: const Color(0xFFFE9F0F),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Set radius here
                  ),
                ),
                child:  Text("View Contact",style: TextStyle( fontSize: 14.sp,color:  Color(0xFFFDF6F8),),),
              ),

            ),
             SizedBox(width: 8.w),
            Expanded(
              child:ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  backgroundColor: const Color(0xFFFE9F0F),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  "View Full Profile",
                  textAlign: TextAlign.center, // Optional; useful if text spans multiple lines
                  style: TextStyle(
                    fontSize: 14.sp,
                    color:  Color(0xFFFDF6F8),
                  ),
                ),
              )

            ),
          ],
        ),
      ],
    );
  }
}

import 'package:ai_powered_app/screen/realEstate/particular.realEstate.page.dart';
import 'package:ai_powered_app/screen/realEstate/property.Info.page.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (_, child) {
        return MaterialApp(
          title: 'Real Estate App',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            primaryColor: const Color(0xFF00796B),
            scaffoldBackgroundColor: const Color(0xFFF5F5F5),
            textTheme: GoogleFonts.interTextTheme(),
          ),
          home: const RealestateHomePage(),
        );
      },
    );
  }
}

class RealestateHomePage extends StatefulWidget {
  const RealestateHomePage({super.key});

  @override
  State<RealestateHomePage> createState() => _RealestateHomePageState();
}

class _RealestateHomePageState extends State<RealestateHomePage> {
  int _currentBottomNavIndex = 0;
  int _searchTabIndex = 0;
  final PageController _pageController = PageController();

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(),
        onPageChanged: (index) {
          setState(() => _currentBottomNavIndex = index);
        },
        children: const [
          HomeContent(),
          Center(child: Text("Browse Page")),
          Center(child: Text("My Jobs")),
          PropertyInfoPage(),
        ],
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildBottomNavigationBar() {
    return Padding(
      padding: EdgeInsets.only(left: 20.w, right: 20.w, bottom: 20.h),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20.r),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF00796B),
            borderRadius: BorderRadius.circular(20.r),
          ),
          child: BottomNavigationBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            currentIndex: _currentBottomNavIndex,
            onTap: (index) {
              setState(() => _currentBottomNavIndex = index);
              _pageController.jumpToPage(index);
            },
            type: BottomNavigationBarType.fixed,
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.white60,
            showUnselectedLabels: true,
            selectedLabelStyle: GoogleFonts.alexandria(
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
            ),
            unselectedLabelStyle: GoogleFonts.gothicA1(
              fontSize: 12.sp,
              fontWeight: FontWeight.w400,
            ),
            items: const [
              BottomNavigationBarItem(
                  icon: Icon(Icons.home), label: 'Home'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.explore_outlined), label: 'Browse'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.history_rounded), label: 'History'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.person_outlined), label: 'Profile'),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeContent extends StatefulWidget {
  const HomeContent({super.key});

  @override
  State<HomeContent> createState() => _HomeContentState();
}

class _HomeContentState extends State<HomeContent> {
  int _searchTabIndex = 0;

  final List<String> _sliderImages = const [
    "assets/image.png",
    "assets/image (2).png",
    "assets/image (3).png",
  ];

  final List<Map<String, String>> _recentProperties = const [
    {
      "imageUrl": "assets/recently.png",
      "name": "Kelwa house town",
      "price": "₹1500/m",
    },
    {
      "imageUrl": "assets/recently2.png",
      "name": "Lakeside retreat",
      "price": "₹2000/m",
    },
    {
      "imageUrl": "assets/recently3.png",
      "name": "Mountain view cabin",
      "price": "₹2500/m",
    },
    {
      "imageUrl": "assets/recently4.png",
      "name": "Urban skyline apartment",
      "price": "₹3000/m",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeaderSection(),
          SizedBox(height: 15.h),
          _buildSearchTypeTabs(),
          SizedBox(height: 15.h),
          _buildPropertyCarousel(),
          SizedBox(height: 30.h),
          _buildRecentlyAddedSection(),
        ],
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      width: double.infinity,
      height: 323.h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30.r),
          bottomRight: Radius.circular(30.r),
        ),
        color: const Color(0xFF00796B),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 24.w),
        child: Column(
          children: [
            SizedBox(height: 40.h),
            _buildAppBar(),
            SizedBox(height: 16.h),
            _buildSearchField(),
            SizedBox(height: 20.h),
            _buildPropertyTypeGrid(),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Row(
      children: [
        Container(
          width: 40.w,
          height: 40.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.r),
            color: Colors.white,
          ),
          child: Center(
            child: Image.asset(
              "assets/rajveer.png",
              color: const Color(0xFF00796B),
            ),
          ),
        ),
        SizedBox(width: 10.w),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Real estate",
              style: GoogleFonts.inter(
                fontSize: 18.sp,
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
            Text(
              "Welcome Rahul!",
              style: GoogleFonts.inter(
                fontSize: 13.sp,
                fontWeight: FontWeight.w500,
                color: Colors.white70,
              ),
            ),
          ],
        ),
        const Spacer(),
        Container(
          width: 40.w,
          height: 40.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.r),
            border: Border.all(
              color: const Color.fromARGB(25, 255, 255, 255),
              width: 1.w,
            ),
          ),
          child: const Center(
            child: Icon(
              Icons.notifications_none,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchField() {
    return TextField(
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(
          horizontal: 24.w,
          vertical: 15.h,
        ),
        hintText: "Search property",
        hintStyle: GoogleFonts.inter(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          color: Colors.white38,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: const BorderSide(
            color: Color.fromARGB(25, 255, 255, 255),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: const BorderSide(
            color: Color.fromARGB(25, 255, 255, 255),
          ),
        ),
        prefixIcon: const Icon(Icons.search, color: Colors.white54),
      ),
    );
  }

  Widget _buildPropertyTypeGrid() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: const [
        PropertyTypeButton(
          image: "assets/pro.png",
          label: "Buy Property",
        ),
        PropertyTypeButton(
          image: "assets/sale.png",
          label: 'Rent Property',
        ),
        PropertyTypeButton(
          image: "assets/rent.png",
          label: 'Sell Property',
        ),
      ],
    );
  }

  Widget _buildSearchTypeTabs() {
    return Center(
      child: Container(
        width: 220.w,
        height: 45.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(40.r),
          color: Colors.white,
        ),
        child: Padding(
          padding: EdgeInsets.all(8.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildSearchTabButton("Recommended", 0),
              _buildSearchTabButton("Nearby", 1),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchTabButton(String text, int index) {
    return GestureDetector(
      onTap: () => setState(() => _searchTabIndex = index),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(40.r),
          color: _searchTabIndex == index
              ? const Color(0xFFF4B400)
              : Colors.transparent,
        ),
        child: Center(
          child: Text(
            text,
            style: GoogleFonts.inter(
              fontSize: 13.sp,
              fontWeight: FontWeight.w500,
              color: const Color(0xFF1E1E1E),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPropertyCarousel() {
    return CarouselSlider(
      items: _sliderImages.map((imagePath) {
        return PropertyCarouselItem(imagePath: imagePath);
      }).toList(),
      options: CarouselOptions(
        height: 240.h,
        viewportFraction: 0.9,
        enableInfiniteScroll: true,
        autoPlay: true,
        autoPlayInterval: const Duration(seconds: 3),
        autoPlayAnimationDuration: const Duration(milliseconds: 800),
        enlargeCenterPage: true,
      ),
    );
  }

  Widget _buildRecentlyAddedSection() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 24.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Recently Added",
            style: GoogleFonts.inter(
              fontSize: 20.sp,
              fontWeight: FontWeight.w500,
              color: const Color(0xFF030016),
            ),
          ),
          SizedBox(height: 20.h),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 10.h,
              crossAxisSpacing: 10.w,
              childAspectRatio: 0.85,
            ),
            itemCount: _recentProperties.length,
            itemBuilder: (context, index) {
              return PropertyCard(
                imageUrl: _recentProperties[index]["imageUrl"]!,
                name: _recentProperties[index]["name"]!,
                price: _recentProperties[index]["price"]!,
              );
            },
          ),
        ],
      ),
    );
  }
}

class PropertyTypeButton extends StatelessWidget {
  final String image;
  final String label;

  const PropertyTypeButton({
    super.key,
    required this.image,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 117.w,
          height: 80.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(11.r),
            color: const Color.fromARGB(255, 51, 148, 137),
          ),
          child: Center(child: Image.asset(image)),
        ),
        SizedBox(height: 13.h),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}

class PropertyCarouselItem extends StatelessWidget {
  final String imagePath;

  const PropertyCarouselItem({
    super.key,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 20.w),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.r),
      ),
      child: Stack(
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                CupertinoPageRoute(
                  builder: (context) => const ParticularRealestatePage(),
                ),
              );
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20.r),
              child: Image.asset(
                imagePath,
                width: 330.w,
                height: 240.h,
                fit: BoxFit.cover,
              ),
            ),
          ),
          Positioned(
            left: 13.w,
            top: 13.h,
            child: Container(
              width: 50.w,
              height: 24.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40.r),
                color: Colors.white,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.star,
                    color: const Color(0xFFF4B400),
                    size: 15.sp,
                  ),
                  SizedBox(width: 3.w),
                  Text(
                    "4.5",
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFF1E1E1E),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 13.h,
            left: 0,
            right: 0,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 13.w),
              child: Container(
                width: 304.w,
                height: 65.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(13.r),
                  color: Colors.white,
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Maharashtra Hilltop Retreat",
                            style: GoogleFonts.inter(
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xFF1E1E1E),
                            ),
                          ),
                          Text(
                            "₹1500",
                            style: GoogleFonts.inter(
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w400,
                              color: const Color(0xFF1E1E1E),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "2 Bedroom  |  1480m²",
                            style: GoogleFonts.inter(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xFF9A97AE),
                            ),
                          ),
                          Text(
                            "/month",
                            style: GoogleFonts.inter(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w400,
                              color: const Color(0xFF9A97AE),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PropertyCard extends StatelessWidget {
  final String imageUrl;
  final String name;
  final String price;

  const PropertyCard({
    super.key,
    required this.imageUrl,
    required this.name,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 200.w,
          height: 180.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.r),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20.r),
            child: Image.asset(
              imageUrl,
              fit: BoxFit.cover,
            ),
          ),
        ),
        SizedBox(height: 10.h),
        Padding(
          padding: EdgeInsets.only(left: 15.w),
          child: Text(
            name,
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xff1E1E1E),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(left: 15.w),
          child: Text(
            price,
            style: GoogleFonts.inter(
              fontSize: 12.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xff9A97AE),
            ),
          ),
        ),
      ],
    );
  }
}
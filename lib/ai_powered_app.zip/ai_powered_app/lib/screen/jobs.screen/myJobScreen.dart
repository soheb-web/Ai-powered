import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';

import '../../data/models/jobApplicationModel.dart';
import '../../data/providers/myJob.dart';

class MyJobApplication extends ConsumerStatefulWidget {
  const MyJobApplication({super.key});
  @override
  ConsumerState<MyJobApplication> createState() => _MyJobApplicationState();
}

class _MyJobApplicationState extends ConsumerState<MyJobApplication> {

  // ... other existing variables ...
  String? userId; // Make nullable since we'll load it asynchronously

  @override
  void initState() {
    super.initState();
    _loadUserId();
  }

  Future<void> _loadUserId() async {
    final box = await Hive.openBox('userdata');
    setState(() {
      userId = box.get('userName');
    });
  }
  @override
  Widget build(BuildContext context) {
    final jobApplicationsAsync = ref.watch(myJobsBasedProvider);

    return Scaffold(
        backgroundColor: const Color(0xFFF5F8FA),
      body:

      Column(children: [
        SizedBox(height: 60.h),
        Row(
          children: [
            SizedBox(width: 24.w),
            Container(
              width: 40.w,
              height: 40.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.r),
                color: const Color(0xFF0A66C2),
              ),
              child: Center(
                child: Image.asset(
                  "assets/rajveer.png",
                  color: const Color(0xFFFFFFFF),
                ),
              ),
            ),
            SizedBox(width: 10.w),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Job Portal",
                  style: GoogleFonts.alexandria(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xFF030016),
                    letterSpacing: -1,
                  ),
                ),
                Text(
                  '$userId',
                  style: GoogleFonts.alexandria(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xFF9A97AE),
                    letterSpacing: -1,
                  ),
                ),
              ],
            ),
            const Spacer(),
            Container(
              width: 40.w,
              height: 40.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.r),
                border: Border.all(color: Colors.black12, width: 1.w),
              ),
              child: const Center(child: Icon(Icons.notifications_none)),
            ),
            SizedBox(width: 24.w),
          ],
        ),


        jobApplicationsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stack) => Center(child: Text('Error: $error')),
          data: (jobApplications) {
            if (jobApplications.applications.isEmpty) {
              return const Center(child: Text('No applications found'));
            }
            return
              Expanded(child:
              ListView.builder(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              itemCount: jobApplications.applications.length,
              itemBuilder: (context, index) {
                final application = jobApplications.applications[index];
                return _buildApplicationCard(application);
              },
              ) );
          },
        ),
      ],)


    );
  }

  Widget _buildApplicationCard(Application application) {
    return Card(
      color: Colors.white,
      margin:  EdgeInsets.all(8.w),
      child: Padding(
        padding:  EdgeInsets.all(16.sp),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              application.jobTitle,
              style:  TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
              ),
            ),
             SizedBox(height: 8.h),
            Text(
              application.company,
              style: TextStyle(
                fontSize: 16.sp,
                color: Colors.grey[600],
              ),
            ),
             SizedBox(height: 8.h),
            Row(
              // mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(child:
                Text(
                  'Status: ${application.status}',
                  style: TextStyle(
                    color: _getStatusColor(application.status),
                    fontWeight: FontWeight.w500,
                  ),
                ),),
                Expanded(child:
                Text(
                  'Applied: ${application.appliedDate}',
                  style: const TextStyle(color: Colors.grey),
                ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'approved':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'rejected':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}

class JobApplicationListModel {
  final List<Application> applications;

  JobApplicationListModel({required this.applications});

  factory JobApplicationListModel.fromJson(Map<String, dynamic> json) {
    return JobApplicationListModel(
      applications: (json['applications'] as List)
          .map((e) => Application.fromJson(e))
          .toList(),
    );
  }
}
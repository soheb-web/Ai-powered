import 'package:ai_powered_app/screen/resister.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import '../core/auth/login.auth.dart';

class LoginPage extends ConsumerStatefulWidget {
  final String title;

  LoginPage(this.title, {super.key});

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool _buttonLoader = false;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.w),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 20.h),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Enter your Email & Password",
                  style: GoogleFonts.gothicA1(
                    fontSize: 30.sp,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF030016),
                    letterSpacing: -1,
                  ),
                ),
                SizedBox(height: 30.h),

                _buildLabel("Enter Email"),
                _buildTextFormField(
                  _getLoginButtonColor(widget.title),
                  controller: emailController,
                  hint: "Enter Email Address",
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) return 'Email is required';
                    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
                    if (!emailRegex.hasMatch(value)) return 'Enter a valid email';
                    return null;
                  },
                ),
                SizedBox(height: 15.h),

                _buildLabel("Enter Password"),
                _buildTextFormField(
                  _getLoginButtonColor(widget.title),
                  controller: passwordController,
                  hint: "Password",
                  obscure: true,
                  validator: (value) {
                    if (value == null || value.isEmpty) return 'Password is required';
                    if (value.length < 5) return 'Password must be at least 5 characters';
                    return null;
                  },
                ),

                SizedBox(height: 25.h),

                GestureDetector(
                  onTap: () async {
                    if (_buttonLoader) return;
                    if (!(_formKey.currentState?.validate() ?? false)) return;
                    setState(() => _buttonLoader = true);
                    try {

    if ( widget.title.toUpperCase() == "JOBS")

    {
      await Auth.jobsLogin(
        emailController.text.trim(),
        passwordController.text, context,);}
    else  if(widget.title.toUpperCase() == "REAL ESTATE"){

      await Auth.realStateLogin(
        emailController.text.trim(),
        passwordController.text, context,);
    }

    else
    {
      await Auth.login(
        emailController.text.trim(),
        passwordController.text,
        context,
      );
    }

                    } finally {
                      setState(() => _buttonLoader = false);
                    }
                  },
                  child: Center(
                    child: _buttonLoader
                        ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF9A97AE)),
                      ),
                    )
                        : Container(
                      width: double.infinity,
                      height: 53.h,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15.r),
                        color: _getLoginButtonColor(widget.title),
                      ),
                      child: Center(
                        child: Text(
                          'Login',
                          style: GoogleFonts.gothicA1(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w500,
                            color: const Color(0xFF9A97AE),
                            letterSpacing: -1,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 20.h),

                Center(
                  child: Text.rich(
                    TextSpan(
                      text: "By clicking, I accept the",
                      style: GoogleFonts.gothicA1(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w400,
                        color: const Color(0xFF9A97AE),
                      ),
                      children: [
                        TextSpan(
                          text: " terms of service ",
                          style: GoogleFonts.gothicA1(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const TextSpan(text: "and "),
                        TextSpan(
                          text: "privacy policy",
                          style: GoogleFonts.gothicA1(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 46.h),

                Row(
                  children: [
                    const Expanded(child: Divider(color: Colors.black12)),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10.w),
                      child: Text(
                        "or login with",
                        style: GoogleFonts.gothicA1(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w500,
                          color: _getLoginButtonColor(widget.title),
                        ),
                      ),
                    ),
                    const Expanded(child: Divider(color: Colors.black12)),
                  ],
                ),

                SizedBox(height: 24.h),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    WithBody(image: "assets/mail.png"),
                    SizedBox(width: 10),
                    WithBody(image: "assets/g.png"),
                    SizedBox(width: 10),
                    WithBody(image: "assets/facebook.png"),
                  ],
                ),

                SizedBox(height: 20.h),

                Center(
                  child: GestureDetector(
                    onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => RegisterPage(title: widget.title)),
                        );},


                    child: Text(
                      "Register Click Here",
                      style: GoogleFonts.gothicA1(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w500,
                        color: _getLoginButtonColor(widget.title),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _getLoginButtonColor(String title) {
    switch (title.toUpperCase()) {
      case "MATRIMONY":
        return const Color(0xFFFF9E0D);
      case "JOBS":
        return const Color(0xFF0A66C2);
      case "REAL ESTATE":
        return const Color(0xFF00796B);
      default:
        return const Color(0xFFFF9E0D);
    }
  }
}

class WithBody extends StatelessWidget {
  final String image;
  const WithBody({super.key, required this.image});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44.w,
      height: 44.h,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFFE6E1D8)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Image.asset(image, fit: BoxFit.contain),
      ),
    );
  }
}

Widget _buildLabel(String label) {
  return Text(
    label,
    style: GoogleFonts.gothicA1(
      fontSize: 16.sp,
      fontWeight: FontWeight.w500,
      color: const Color(0xFF030016),
    ),
  );
}

Widget _buildTextFormField(Color getLoginButtonColor, {
  required TextEditingController controller,
  String? hint,
  bool obscure = false,
  TextInputType keyboardType = TextInputType.text,
  String? Function(String?)? validator,
}) {
  final border = OutlineInputBorder(
    borderRadius: BorderRadius.circular(15.r),
    borderSide: BorderSide(color: getLoginButtonColor, width: 1.5.w),
  );

  return TextFormField(
    controller: controller,
    obscureText: obscure,
    keyboardType: keyboardType,
    validator: validator,
    decoration: InputDecoration(
      contentPadding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
      hintText: hint,
      hintStyle: GoogleFonts.gothicA1(color: Colors.grey, fontSize: 14.sp),
      enabledBorder: border,
      focusedBorder: border,
      errorBorder: border,
      focusedErrorBorder: border,
      disabledBorder: border,
    ),
  );
}

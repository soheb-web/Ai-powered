package com.example.ai_powered_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

/*

import 'package:ai_powered_app/screen/realEstate/location.realEstate.page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';





final furnishingProvider = StateProvider<String?>((ref) => null);
final areaControllerProvider = Provider.autoDispose<TextEditingController>((ref) => TextEditingController());
final bathroomsControllerProvider = Provider.autoDispose<TextEditingController>((ref) => TextEditingController());
final badroomesControllerProvider = Provider.autoDispose<TextEditingController>((ref) => TextEditingController());

class PropertyRealestateDetails extends ConsumerWidget {
  final int? propertyId;
  const PropertyRealestateDetails(this.propertyId,{super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {



    final  furnitureList = [
      "Fully Furnished",
      "Semi Furnished",
      "Unfurnished",
    ];


    final badroomesController  = ref.watch(badroomesControllerProvider);
    final bathroomsController  = ref.watch(bathroomsControllerProvider);
    final areaController = ref.watch(areaControllerProvider);
    final list = ref.watch(furnishingProvider);

    void validateAndNavigate() {
      if (list == null) {
        Fluttertoast.showToast(
          msg: "Please select a Furnishing",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (areaController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please Enter Area",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (bathroomsController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please Enter No. Bathrooms",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (badroomesController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please Enter No. Bedrooms",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }


      Navigator.push(
        context,
        CupertinoPageRoute(
          builder: (context) => LocationRealestatePage(),
        ),
      );
    }


    return Scaffold(



      backgroundColor: Color(0xFFF5F5F5),
      appBar: AppBar(backgroundColor: Color(0xFFF5F5F5)),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(left: 24.w, right: 24.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20.h),
              Text(
                "Property Details",
                style: GoogleFonts.inter(
                  fontSize: 30.sp,
                  fontWeight: FontWeight.w400,
                  color: Color(0xFF030016),
                  letterSpacing: -1.3,
                ),
              ),
              Text(
                "Tell us about your Property ",
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w400,
                  color: Color(0xFF9A97AE),
                ),
              ),
              SizedBox(height: 15.h),

              buildDropDown(
                hint: "Select Furnishing",
                items: furnitureList,
                value: list,
                onChange: (value) => ref.read(furnishingProvider.notifier).state = value,
              ),
              SizedBox(height: 15.h),
              TextField(
                keyboardType: TextInputType.number,
                controller: areaController,
                decoration: InputDecoration(

                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "Enter Area",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              TextField(
                keyboardType: TextInputType.number,
                controller: bathroomsController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "Enter No. of Bathrooms",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              TextField(
                keyboardType: TextInputType.number,
                controller: badroomesController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "Enter No. of Badrooms",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              GestureDetector(
                onTap: () {
                  validateAndNavigate();

                },
                child: Container(
                  width: 392.w,
                  height: 53.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15.r),
                    color: Color(0xFF00796B),
                  ),
                  child: Center(
                    child: Text(
                      "Continue",
                      style: GoogleFonts.inter(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

}



class buildDropDown extends StatelessWidget {
  final String hint;
  final List<String> items;
  final String? value;
  final Function(String?) onChange;

  const buildDropDown({
    super.key,
    required this.hint,
    required this.items,
    this.value,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      icon: const Icon(Icons.keyboard_arrow_down),
      value: (value != null && items.contains(value)) ? value : null,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        hintText: hint,
        hintStyle: GoogleFonts.gothicA1(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          color: const Color(0xFF030016),
          letterSpacing: -0.2,
        ),
      ),
      items: items.map((item) {
        return DropdownMenuItem(
          value: item,
          child: Text(
            item,
            style: GoogleFonts.gothicA1(
              fontSize: 16.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF030016),
              letterSpacing: -0.2,
            ),
          ),
        );
      }).toList(),
      onChanged: onChange,
    );
  }
}
*/

import 'package:ai_powered_app/data/models/PropertyDetailModel.dart';
import 'package:ai_powered_app/data/providers/propertiesProvider.dart';
import 'package:ai_powered_app/screen/realEstate/location.realEstate.page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../data/providers/propertyDetail.dart';

final furnishingProvider = StateProvider<String?>((ref) => null);
final areaControllerProvider = Provider.autoDispose<TextEditingController>(
  (ref) => TextEditingController(),
);
final bathroomsControllerProvider = Provider.autoDispose<TextEditingController>(
  (ref) => TextEditingController(),
);
final badroomesControllerProvider = Provider.autoDispose<TextEditingController>(
  (ref) => TextEditingController(),
);

class PropertyRealestateDetails extends ConsumerStatefulWidget {
  final int? propertyId;
  const PropertyRealestateDetails(this.propertyId, {super.key});

  @override
  ConsumerState<PropertyRealestateDetails> createState() =>
      _PropertyRealestateDetailsState();
}

class _PropertyRealestateDetailsState
    extends ConsumerState<PropertyRealestateDetails> {
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    // Fetch property details if propertyId is not -1
    if (widget.propertyId != null && widget.propertyId != -1) {
      _fetchAndSetPropertyData();
    }
  }

  void _fetchAndSetPropertyData() async {
    final propertyId = widget.propertyId;
    if (propertyId == null) return;

    setState(() {
      isLoading = true;
    });

    try {
      final propertyDetail = await ref.read(
        propertyDetailProvider(propertyId).future,
      );
      final property = propertyDetail.property;
      if (property != null) {
        // Set the form fields with fetched data
        ref.read(furnishingProvider.notifier).state = property.furnishSuch;
        ref.read(areaControllerProvider).text =
            (double.tryParse(property.area ?? '')?.toInt().toString()) ?? '';

        ref.read(bathroomsControllerProvider).text =
            property.bathrooms?.toString() ?? '';
        ref.read(badroomesControllerProvider).text =
            property.bedrooms?.toString() ?? '';
      } else {
        Fluttertoast.showToast(
          msg: "No property data found",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Failed to load property details: $e",
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 12.sp,
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final furnitureList = ["Fully Furnished", "Semi Furnished", "Unfurnished"];
    final badroomesController = ref.watch(badroomesControllerProvider);
    final bathroomsController = ref.watch(bathroomsControllerProvider);
    final areaController = ref.watch(areaControllerProvider);
    final list = ref.watch(furnishingProvider);

    void validateAndNavigate() {
      if (list == null) {
        Fluttertoast.showToast(
          msg: "Please select a Furnishing",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (areaController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please Enter Area",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (bathroomsController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please Enter No. Bathrooms",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (badroomesController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please Enter No. Bedrooms",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }

      Navigator.push(
      context,
      CupertinoPageRoute(
      builder: (context) => LocationRealestatePage(
      widget.propertyId, // Pass propertyId for further use
      ),
      ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(backgroundColor: const Color(0xFFF5F5F5)),
      body:
          isLoading
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.only(left: 24.w, right: 24.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 20.h),
                      Text(
                        widget.propertyId != null && widget.propertyId != -1
                            ? "Update Property Details"
                            : "Property Details",
                        style: GoogleFonts.inter(
                          fontSize: 30.sp,
                          fontWeight: FontWeight.w400,
                          color: const Color(0xFF030016),
                          letterSpacing: -1.3,
                        ),
                      ),
                      Text(
                        widget.propertyId != null && widget.propertyId != -1
                            ? "Update details about your Property"
                            : "Tell us about your Property",
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w400,
                          color: const Color(0xFF9A97AE),
                        ),
                      ),
                      SizedBox(height: 15.h),
                      buildDropDown(
                        hint: "Select Furnishing",
                        items: furnitureList,
                        value: list,
                        onChange:
                            (value) =>
                                ref.read(furnishingProvider.notifier).state =
                                    value,
                      ),
                      SizedBox(height: 15.h),
                      TextField(
                        keyboardType: TextInputType.number,
                        controller: areaController,
                        decoration: InputDecoration(
                          contentPadding: EdgeInsets.only(
                            left: 20.w,
                            right: 20.w,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          hintText: "Enter Area",
                          hintStyle: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF030016),
                            letterSpacing: -0.2,
                          ),
                        ),
                      ),
                      SizedBox(height: 15.h),
                      TextField(
                        keyboardType: TextInputType.number,
                        controller: bathroomsController,
                        decoration: InputDecoration(
                          contentPadding: EdgeInsets.only(
                            left: 20.w,
                            right: 20.w,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          hintText: "Enter No. of Bathrooms",
                          hintStyle: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF030016),
                            letterSpacing: -0.2,
                          ),
                        ),
                      ),
                      SizedBox(height: 15.h),
                      TextField(
                        keyboardType: TextInputType.number,
                        controller: badroomesController,
                        decoration: InputDecoration(
                          contentPadding: EdgeInsets.only(
                            left: 20.w,
                            right: 20.w,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          hintText: "Enter No. of Bedrooms",
                          hintStyle: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF030016),
                            letterSpacing: -0.2,
                          ),
                        ),
                      ),
                      SizedBox(height: 15.h),
                      GestureDetector(
                        onTap: validateAndNavigate,
                        child: Container(
                          width: 392.w,
                          height: 53.h,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15.r),
                            color: const Color(0xFF00796B),
                          ),
                          child: Center(
                            child: Text(
                              widget.propertyId != null &&
                                      widget.propertyId != -1
                                  ? "Update"
                                  : "Continue",
                              style: GoogleFonts.inter(
                                fontSize: 18.sp,
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
    );
  }
}

class buildDropDown extends StatelessWidget {
  final String hint;
  final List<String> items;
  final String? value;
  final Function(String?) onChange;

  const buildDropDown({
    super.key,
    required this.hint,
    required this.items,
    this.value,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      icon: const Icon(Icons.keyboard_arrow_down),
      value: (value != null && items.contains(value)) ? value : null,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: const BorderSide(color: Color(0xFFDADADA), width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: const BorderSide(color: Color(0xFFDADADA), width: 1.5),
        ),
        hintText: hint,
        hintStyle: GoogleFonts.gothicA1(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          color: const Color(0xFF030016),
          letterSpacing: -0.2,
        ),
      ),
      items:
          items.map((item) {
            return DropdownMenuItem(
              value: item,
              child: Text(
                item,
                style: GoogleFonts.gothicA1(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF030016),
                  letterSpacing: -0.2,
                ),
              ),
            );
          }).toList(),
      onChanged: onChange,
    );
  }
}

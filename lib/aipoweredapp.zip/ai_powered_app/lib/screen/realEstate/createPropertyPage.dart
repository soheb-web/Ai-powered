/*



import 'package:ai_powered_app/screen/realEstate/property.realEstate.details.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../matrimony.screen/start.page.dart';

final propertyTypeProvider = StateProvider<String?>((ref) => null);
final propertyListProvider = StateProvider<String?>((ref) => null);
final bhkProvider = StateProvider<String?>((ref) => null);
final priceControllerProvider = Provider.autoDispose<TextEditingController>((ref) => TextEditingController());
final descriptionControllerProvider = Provider.autoDispose<TextEditingController>((ref) => TextEditingController());
final titleControllerProvider = Provider.autoDispose<TextEditingController>((ref) => TextEditingController());

class CreateProperty extends ConsumerWidget {
  final int? propertyId;
  const CreateProperty(this.propertyId,{super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final descriptionController = ref.watch(descriptionControllerProvider);
    final titleController = ref.watch(titleControllerProvider);
    final priceController = ref.watch(priceControllerProvider);
    final propertyType = ["rent", "sale"];
    final propertyTypeList = ref.watch(propertyTypeProvider);
    final property = ["apartment", "villa", "land"];
    final propertyList = ref.watch(propertyListProvider);
    final bhkList = ["1", "2", "3", "4", "5", "6"];
    final bhkFinalList = ref.watch(bhkProvider);

    void validateAndNavigate() {
      if (propertyList == null) {
        Fluttertoast.showToast(
          msg: "Please select a listing type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (propertyTypeList == null) {
        Fluttertoast.showToast(
          msg: "Please select a property type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (bhkFinalList == null) {
        Fluttertoast.showToast(
          msg: "Please select a BHK type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (priceController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a price",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (titleController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a title",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }

      if (descriptionController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a description",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }

      // If all fields are valid, navigate to PropertyRealestateDetails
      Navigator.push(
        context,
        CupertinoPageRoute(
          builder: (context) => PropertyRealestateDetails(

          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Color(0xFFF5F5F5),
      appBar: AppBar(backgroundColor: Color(0xFFF5F5F5)),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(left: 24.w, right: 24.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20.h),
              Text(
                "Property Type & Listing Info",
                style: GoogleFonts.inter(
                  fontSize: 30.sp,
                  fontWeight: FontWeight.w400,
                  color: Color(0xFF030016),
                  letterSpacing: -1.3,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Let's Start with the Basics",
                    style: GoogleFonts.inter(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w400,
                      color: Color(0xFF9A97AE),
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      final box = await Hive.openBox('userdata');
                      await box.clear(); // Clear saved user data
                      if (context.mounted) {
                        Navigator.pushReplacement(
                          context,
                          CupertinoPageRoute(builder: (_) => const StartPage()),
                        );
                      }
                    },
                    child: Container(
                      width: 103.w,
                      height: 53.h,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15.r),
                        color: Color(0xFF00796B),
                      ),
                      child: Center(
                        child: Text(
                          "Logout",
                          style: GoogleFonts.gothicA1(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),


              SizedBox(height: 20.h),
              buildDropDown(
                hint: "Select Property",
                items: property,
                value: propertyList,
                onChange: (value) => ref.read( propertyListProvider.notifier).state = value,
              ),
              SizedBox(height: 15.h),
              buildDropDown(
                hint: "Select Property Type",
                items: propertyType,
                value: propertyTypeList,
                onChange: (value) => ref.read(propertyTypeProvider.notifier).state = value,
              ),
              SizedBox(height: 15.h),
              buildDropDown(
                hint: "Select BHK",
                items: bhkList,
                value: bhkFinalList,
                onChange: (value) => ref.read(bhkProvider.notifier).state = value,
              ),
              SizedBox(height: 15.h),
              TextField(
                keyboardType: TextInputType.number,
                controller: priceController,
                decoration: InputDecoration(

                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "Enter Price",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),

              SizedBox(height: 15.h),
              TextField(
                controller: titleController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "title",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),


              SizedBox(height: 15.h),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "Description",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              GestureDetector(
                onTap: validateAndNavigate,
                child: Container(
                  width: 392.w,
                  height: 53.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15.r),
                    color: Color(0xFF00796B),
                  ),
                  child: Center(
                    child: Text(
                      "Continue",
                      style: GoogleFonts.inter(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class buildDropDown extends StatelessWidget {
  final String hint;
  final List<String> items;
  final String? value;
  final Function(String?) onChange;

  const buildDropDown({
    super.key,
    required this.hint,
    required this.items,
    this.value,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      icon: const Icon(Icons.keyboard_arrow_down),
      value: (value != null && items.contains(value)) ? value : null,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        hintText: hint,
        hintStyle: GoogleFonts.gothicA1(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          color: const Color(0xFF030016),
          letterSpacing: -0.2,
        ),
      ),
      items: items.map((item) {
        return DropdownMenuItem(
          value: item,
          child: Text(
            item,
            style: GoogleFonts.gothicA1(
              fontSize: 16.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF030016),
              letterSpacing: -0.2,
            ),
          ),
        );
      }).toList(),
      onChanged: onChange,
    );
  }
}*/
/*

import 'package:ai_powered_app/screen/realEstate/property.realEstate.details.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';

import '../../data/providers/propertyDetail.dart';
import '../matrimony.screen/start.page.dart';

final propertyTypeProvider = StateProvider<String?>((ref) => null);
final propertyListProvider = StateProvider<String?>((ref) => null);
final bhkProvider = StateProvider<String?>((ref) => null);
final priceControllerProvider = Provider.autoDispose<TextEditingController>(
  (ref) => TextEditingController(),
);
final descriptionControllerProvider =
    Provider.autoDispose<TextEditingController>(
      (ref) => TextEditingController(),
    );
final titleControllerProvider = Provider.autoDispose<TextEditingController>(
  (ref) => TextEditingController(),
);

class CreateProperty extends ConsumerStatefulWidget {
  final int? propertyId;
  const CreateProperty(this.propertyId, {super.key});

  @override
  ConsumerState<CreateProperty> createState() => _CreatePropertyState();
}

class _CreatePropertyState extends ConsumerState<CreateProperty> {
  @override
  void initState() {
    super.initState();
    // Fetch property details if propertyId is not -1
    if (widget.propertyId != null && widget.propertyId != -1) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _fetchAndSetPropertyData();
      });
    }
  }

  void _fetchAndSetPropertyData() async {
    final propertyId = widget.propertyId;
    if (propertyId == null) return;

    final propertyDetailAsync = ref.read(propertyDetailProvider(propertyId));
    propertyDetailAsync.when(
      data: (propertyDetail) {
        final property = propertyDetail.property;
        // if (property != null) {
          // Set the form fields with fetched data
          ref.read(propertyTypeProvider.notifier).state = property!.propertyType;
          ref.read(propertyListProvider.notifier).state = property.category;
          ref.read(bhkProvider.notifier).state = property.bhk?.toString();
          ref.read(priceControllerProvider).text = property.price ?? '';
          ref.read(titleControllerProvider).text = property.title ?? '';
          ref.read(descriptionControllerProvider).text =
              property.description ?? '';
        // }
      },
      loading: () {
        // Optionally show a loading state
      },
      error: (err, stack) {
        Fluttertoast.showToast(
          msg: "Failed to load property details: $err",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final descriptionController = ref.watch(descriptionControllerProvider);
    final titleController = ref.watch(titleControllerProvider);
    final priceController = ref.watch(priceControllerProvider);
    final propertyType = ["rent", "sale"];
    final propertyTypeList = ref.watch(propertyTypeProvider);
    final property = ["apartment", "villa", "land"];
    final propertyList = ref.watch(propertyListProvider);
    final bhkList = ["1", "2", "3", "4", "5", "6"];
    final bhkFinalList = ref.watch(bhkProvider);

    void validateAndNavigate() {
      if (propertyList == null) {
        Fluttertoast.showToast(
          msg: "Please select a listing type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (propertyTypeList == null) {
        Fluttertoast.showToast(
          msg: "Please select a property type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (bhkFinalList == null) {
        Fluttertoast.showToast(
          msg: "Please select a BHK type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (priceController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a price",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (titleController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a title",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (descriptionController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a description",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }

      // If all fields are valid, navigate to PropertyRealestateDetails
      // Navigator.push(
      // context,
      // CupertinoPageRoute(
      // builder: (context) => PropertyRealestateDetails(
      // propertyId: widget.propertyId, // Pass propertyId for update
      // ),
      // ),
      // );
    }

    return Scaffold(
      backgroundColor: Color(0xFFF5F5F5),
      appBar: AppBar(backgroundColor: Color(0xFFF5F5F5)),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(left: 24.w, right: 24.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20.h),
              Text(
                widget.propertyId != null && widget.propertyId != -1
                    ? "Update Property"
                    : "Create Property",
                style: GoogleFonts.inter(
                  fontSize: 30.sp,
                  fontWeight: FontWeight.w400,
                  color: Color(0xFF030016),
                  letterSpacing: -1.3,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    widget.propertyId != null && widget.propertyId != -1
                        ? "Update the Property Details"
                        : "Let's Start with the Basics",
                    style: GoogleFonts.inter(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w400,
                      color: Color(0xFF9A97AE),
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      final box = await Hive.openBox('userdata');
                      await box.clear(); // Clear saved user data
                      if (context.mounted) {
                        Navigator.pushReplacement(
                          context,
                          CupertinoPageRoute(builder: (_) => const StartPage()),
                        );
                      }
                    },
                    child: Container(
                      width: 103.w,
                      height: 53.h,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15.r),
                        color: Color(0xFF00796B),
                      ),
                      child: Center(
                        child: Text(
                          "Logout",
                          style: GoogleFonts.gothicA1(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20.h),
              buildDropDown(
                hint: "Select Property",
                items: property,
                value: propertyList,
                onChange:
                    (value) =>
                        ref.read(propertyListProvider.notifier).state = value,
              ),
              SizedBox(height: 15.h),
              buildDropDown(
                hint: "Select Property Type",
                items: propertyType,
                value: propertyTypeList,
                onChange:
                    (value) =>
                        ref.read(propertyTypeProvider.notifier).state = value,
              ),
              SizedBox(height: 15.h),
              buildDropDown(
                hint: "Select BHK",
                items: bhkList,
                value: bhkFinalList,
                onChange:
                    (value) => ref.read(bhkProvider.notifier).state = value,
              ),
              SizedBox(height: 15.h),
              TextField(
                keyboardType: TextInputType.number,
                controller: priceController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "Enter Price",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              TextField(
                controller: titleController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "Title",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 20.w, right: 20.w),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.r),
                    borderSide: BorderSide(
                      color: Color(0xFFDADADA),
                      width: 1.5.w,
                    ),
                  ),
                  hintText: "Description",
                  hintStyle: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF030016),
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              GestureDetector(
                onTap: validateAndNavigate,
                child: Container(
                  width: 392.w,
                  height: 53.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15.r),
                    color: Color(0xFF00796B),
                  ),
                  child: Center(
                    child: Text(
                      widget.propertyId != null && widget.propertyId != -1
                          ? "Update"
                          : "Continue",
                      style: GoogleFonts.inter(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class buildDropDown extends StatelessWidget {
  final String hint;
  final List<String> items;
  final String? value;
  final Function(String?) onChange;

  const buildDropDown({
    super.key,
    required this.hint,
    required this.items,
    this.value,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      icon: const Icon(Icons.keyboard_arrow_down),
      value: (value != null && items.contains(value)) ? value : null,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        hintText: hint,
        hintStyle: GoogleFonts.gothicA1(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          color: const Color(0xFF030016),
          letterSpacing: -0.2,
        ),
      ),
      items:
          items.map((item) {
            return DropdownMenuItem(
              value: item,
              child: Text(
                item,
                style: GoogleFonts.gothicA1(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF030016),
                  letterSpacing: -0.2,
                ),
              ),
            );
          }).toList(),
      onChanged: onChange,
    );
  }
}
*/

import 'package:ai_powered_app/data/models/PropertyDetailModel.dart';
import 'package:ai_powered_app/data/providers/propertiesProvider.dart';
import 'package:ai_powered_app/screen/realEstate/property.realEstate.details.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import '../../data/providers/propertyDetail.dart';
import '../matrimony.screen/start.page.dart';

final propertyTypeProvider = StateProvider<String?>((ref) => null);
final propertyListProvider = StateProvider<String?>((ref) => null);
final bhkProvider = StateProvider<String?>((ref) => null);
final priceControllerProvider = Provider.autoDispose<TextEditingController>(
  (ref) => TextEditingController(),
);
final descriptionControllerProvider =
    Provider.autoDispose<TextEditingController>(
      (ref) => TextEditingController(),
    );
final titleControllerProvider = Provider.autoDispose<TextEditingController>(
  (ref) => TextEditingController(),
);

class CreateProperty extends ConsumerStatefulWidget {
  final int? propertyId;
  const CreateProperty(this.propertyId, {super.key});

  @override
  ConsumerState<CreateProperty> createState() => _CreatePropertyState();
}

class _CreatePropertyState extends ConsumerState<CreateProperty> {
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    // Fetch property details if propertyId is not -1
    if (widget.propertyId != null && widget.propertyId != -1) {
      _fetchAndSetPropertyData();
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _clearFormFields();
      });
    }
  }

  void _clearFormFields() {
    // Reset text controllers
    ref.read(priceControllerProvider).clear();
    ref.read(titleControllerProvider).clear();
    ref.read(descriptionControllerProvider).clear();

    // Reset state providers
    ref.read(propertyTypeProvider.notifier).state = null;
    ref.read(propertyListProvider.notifier).state = null;
    ref.read(bhkProvider.notifier).state = null;
  }

  void _fetchAndSetPropertyData() async {
    final propertyId = widget.propertyId;
    if (propertyId == null) return;

    setState(() {
      isLoading = true;
    });

    try {
      final propertyDetail = await ref.read(
        propertyDetailProvider(propertyId).future,
      );
      final property = propertyDetail.property;
      if (property != null) {
        // Set the form fields with fetched data
        ref.read(propertyTypeProvider.notifier).state = property.propertyType;
        ref.read(propertyListProvider.notifier).state = property.category;
        ref.read(bhkProvider.notifier).state = property.bhk?.toString();
        ref.read(priceControllerProvider).text =
            (double.tryParse(property.price ?? '')?.toInt().toString()) ?? '';

        ref.read(titleControllerProvider).text = property.title ?? '';
        ref.read(descriptionControllerProvider).text =
            property.description ?? '';
      } else {
        Fluttertoast.showToast(
          msg: "No property data found",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Failed to load property details: $e",
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 12.sp,
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    final descriptionController = ref.watch(descriptionControllerProvider);
    final titleController = ref.watch(titleControllerProvider);
    final priceController = ref.watch(priceControllerProvider);
    final propertyType = ["rent", "sale"];
    final propertyTypeList = ref.watch(propertyTypeProvider);
    final property = ["apartment", "villa", "land"];
    final propertyList = ref.watch(propertyListProvider);
    final bhkList = ["1", "2", "3", "4", "5", "6"];
    final bhkFinalList = ref.watch(bhkProvider);

    void validateAndNavigate() {
      if (propertyList == null) {
        Fluttertoast.showToast(
          msg: "Please select a listing type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (propertyTypeList == null) {
        Fluttertoast.showToast(
          msg: "Please select a property type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (bhkFinalList == null) {
        Fluttertoast.showToast(
          msg: "Please select a BHK type",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (priceController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a price",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (titleController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a title",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }
      if (descriptionController.text.trim().isEmpty) {
        Fluttertoast.showToast(
          msg: "Please enter a description",
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 12.sp,
        );
        return;
      }

      // If all fields are valid, navigate to PropertyRealestateDetails
      Navigator.push(
        context,
        CupertinoPageRoute(
          builder:
              (context) => PropertyRealestateDetails(
                widget.propertyId,
              ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(backgroundColor: const Color(0xFFF5F5F5)),
      body:
          isLoading
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.only(left: 24.w, right: 24.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 20.h),
                      Text(
                        widget.propertyId != null && widget.propertyId != -1
                            ? "Update Property"
                            : "Create Property",
                        style: GoogleFonts.inter(
                          fontSize: 30.sp,
                          fontWeight: FontWeight.w400,
                          color: const Color(0xFF030016),
                          letterSpacing: -1.3,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            widget.propertyId != null && widget.propertyId != -1
                                ? "Update the Property Details"
                                : "Let's Start with the Basics",
                            style: GoogleFonts.inter(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w400,
                              color: const Color(0xFF9A97AE),
                            ),
                          ),
                          GestureDetector(
                            onTap: () async {
                              final box = await Hive.openBox('userdata');
                              await box.clear(); // Clear saved user data
                              if (context.mounted) {
                                Navigator.pushReplacement(
                                  context,
                                  CupertinoPageRoute(
                                    builder: (_) => const StartPage(),
                                  ),
                                );
                              }
                            },
                            child: Container(
                              width: 103.w,
                              height: 53.h,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15.r),
                                color: const Color(0xFF00796B),
                              ),
                              child: Center(
                                child: Text(
                                  "Logout",
                                  style: GoogleFonts.gothicA1(
                                    fontSize: 18.sp,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20.h),
                      buildDropDown(
                        hint: "Select Property",
                        items: property,
                        value: propertyList,
                        onChange:
                            (value) =>
                                ref.read(propertyListProvider.notifier).state =
                                    value,
                      ),
                      SizedBox(height: 15.h),
                      buildDropDown(
                        hint: "Select Property Type",
                        items: propertyType,
                        value: propertyTypeList,
                        onChange:
                            (value) =>
                                ref.read(propertyTypeProvider.notifier).state =
                                    value,
                      ),
                      SizedBox(height: 15.h),
                      buildDropDown(
                        hint: "Select BHK",
                        items: bhkList,
                        value: bhkFinalList,
                        onChange:
                            (value) =>
                                ref.read(bhkProvider.notifier).state = value,
                      ),
                      SizedBox(height: 15.h),
                      TextField(
                        keyboardType: TextInputType.number,
                        controller: priceController,
                        decoration: InputDecoration(
                          contentPadding: EdgeInsets.only(
                            left: 20.w,
                            right: 20.w,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          hintText: "Enter Price",
                          hintStyle: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF030016),
                            letterSpacing: -0.2,
                          ),
                        ),
                      ),
                      SizedBox(height: 15.h),
                      TextField(
                        controller: titleController,
                        decoration: InputDecoration(
                          contentPadding: EdgeInsets.only(
                            left: 20.w,
                            right: 20.w,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          hintText: "Title",
                          hintStyle: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF030016),
                            letterSpacing: -0.2,
                          ),
                        ),
                      ),
                      SizedBox(height: 15.h),
                      TextField(
                        controller: descriptionController,
                        decoration: InputDecoration(
                          contentPadding: EdgeInsets.only(
                            left: 20.w,
                            right: 20.w,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.r),
                            borderSide: const BorderSide(
                              color: Color(0xFFDADADA),
                              width: 1.5,
                            ),
                          ),
                          hintText: "Description",
                          hintStyle: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF030016),
                            letterSpacing: -0.2,
                          ),
                        ),
                      ),
                      SizedBox(height: 15.h),
                      GestureDetector(
                        onTap: validateAndNavigate,
                        child: Container(
                          width: 392.w,
                          height: 53.h,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15.r),
                            color: const Color(0xFF00796B),
                          ),
                          child: Center(
                            child: Text(
                              widget.propertyId != null &&
                                      widget.propertyId != -1
                                  ? "Update"
                                  : "Continue",
                              style: GoogleFonts.inter(
                                fontSize: 18.sp,
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
    );
  }
}

class buildDropDown extends StatelessWidget {
  final String hint;
  final List<String> items;
  final String? value;
  final Function(String?) onChange;

  const buildDropDown({
    super.key,
    required this.hint,
    required this.items,
    this.value,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      icon: const Icon(Icons.keyboard_arrow_down),
      value: (value != null && items.contains(value)) ? value : null,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: const BorderSide(color: Color(0xFFDADADA), width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: const BorderSide(color: Color(0xFFDADADA), width: 1.5),
        ),
        hintText: hint,
        hintStyle: GoogleFonts.gothicA1(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          color: const Color(0xFF030016),
          letterSpacing: -0.2,
        ),
      ),
      items:
          items.map((item) {
            return DropdownMenuItem(
              value: item,
              child: Text(
                item,
                style: GoogleFonts.gothicA1(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF030016),
                  letterSpacing: -0.2,
                ),
              ),
            );
          }).toList(),
      onChanged: onChange,
    );
  }
}

import 'package:ai_powered_app/screen/realEstate/propertyDetail.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../data/models/rentModel.dart'; // ✅ Only use rentModel
import '../../data/providers/rentProvider.dart';

class RentProperty extends ConsumerStatefulWidget {
  const RentProperty({super.key});

  @override
  ConsumerState<RentProperty> createState() => _RentPropertyState();
}

class _RentPropertyState extends ConsumerState<RentProperty> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        ref.invalidate(rentListProvider);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final rentList = ref.watch(rentListProvider);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF00796B),
        leading: InkWell(
          onTap: () => Navigator.pop(context),
          child: const Icon(Icons.arrow_back, color: Colors.white),
        ),
        title:  Text(
          "Rent Property",
          style: TextStyle(  fontSize: 20.sp,color: Colors.white),
        ),
      ),
      body: rentList.when(
        data: (data) {
          final rentProperties = data.properties ?? [];
          return ListView.builder(
            itemCount: rentProperties.length,
            itemBuilder: (context, index) {
              final property = rentProperties[index];
              return _buildPropertyCard(property);
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(child: Text("Error: $error")),
      ),
    );
  }

  Widget _buildPropertyCard(Property property) {
    const String baseUrl = 'https://aipowered.globallywebsolutions.com/public/';

    return Card(
      elevation: 2,
      margin: EdgeInsets.all(16.w),
      child: Container(
        margin: EdgeInsets.all(16.w),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.r),
        ),
        child: Stack(
          children: [
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  CupertinoPageRoute(
                    builder: (context) =>  PropertyDetailPage(property.id),
                  ),
                );
              },
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20.r),
                child: (property.photo?.isNotEmpty ?? false)
                    ? Image.network(
                  '$baseUrl${property.photo}',
                  width: 500.w,
                  height: 200.h,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Image.asset(
                      'assets/image.png',
                      width: 500.w,
                      height: 200.h,
                      fit: BoxFit.cover,
                    );
                  },
                )
                    : Image.asset(
                  'assets/image.png',
                  width: 500.w,
                  height: 200.h,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Positioned(
              bottom: 13.h,
              left: 0,
              right: 0,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 13.w),
                child: Card(
                  child: Container(
                    width: 304.w,
                    height: 80.h,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(13.r),
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "${property.title ?? "N/A"}",
                            style: GoogleFonts.inter(
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFF1E1E1E),
                            ),
                          ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "₹${property.price ?? "N/A"}",
                                style: GoogleFonts.inter(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xFF1E1E1E),
                                ),
                              ),
                              Text(
                                "  /month",
                                style: GoogleFonts.inter(
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.w400,
                                  color: const Color(0xFF9A97AE),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 5.h,),
                          Row(
                            // mainAxisAlignment: MainAxisAlignment. ,
                            children: [
                              Text(
                                "${property.bedrooms ?? "N/A"} Bedroom | ${property.area ?? "N/A"}m²",
                                style: GoogleFonts.inter(
                                  fontSize: 12.sp,
                                  fontWeight: FontWeight.w500,
                                  color: const Color(0xFF9A97AE),
                                ),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

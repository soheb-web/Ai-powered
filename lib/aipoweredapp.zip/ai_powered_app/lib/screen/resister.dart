import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/auth/login.auth.dart';
import 'dart:io';

import 'matrimony.screen/education.page.dart';


class RegisterPage extends StatefulWidget {
  final String title;
  const RegisterPage({super.key, required this.title});
  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController roleController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isPasswordVisible = false;
  bool _buttonLoader = false;

  String? listGender;
  String? listRole;
  final genderList = ["male", "female", "other"];
  final roleList = ["buyer", "agent", "other"];

  Future<void> _pickFile() async {
    // Pick a file (image or document) from the gallery
    final pickedFile = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'], // Allow both documents and images
    );

    if (pickedFile != null) {
      setState(() {
        _selectedFile = File(pickedFile.files.single.path!); // Store the selected file
      });
    } else {
      // No file was picked
      print("No file selected");
    }
  }

  File? _selectedFile; // This holds the selected file (image or document)




  Widget _getFilePreview(File file) {
    // Check the file type based on the extension
    String fileExtension = file.path.split('.').last.toLowerCase();

    if (fileExtension == 'jpg' || fileExtension == 'jpeg' || fileExtension == 'png') {
      // It's an image, so show it as an image
      return Image.file(
        file,
        fit: BoxFit.cover,
        width: double.infinity,
      );
    } else if (fileExtension == 'pdf') {
      // It's a PDF, show an icon or file name (as preview)
      return Center(
        child: Icon(Icons.picture_as_pdf, color: Colors.red, size: 50),
      );
    } else if (fileExtension == 'doc' || fileExtension == 'docx') {
      // It's a DOC file, show an icon or file name (as preview)
      return Center(
        child: Icon(Icons.insert_drive_file, color: Colors.blue, size: 50),
      );
    } else {
      // For unsupported file types, show the file name
      return Center(
        child: Text(
          "Selected file: ${file.path.split('/').last}",
          style: TextStyle(color: Colors.black),
        ),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    final themeColor = _getThemeColor(widget.title);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          "Register",
          style: GoogleFonts.gothicA1(
            fontSize: 20.sp,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildLabel("Full Name"),
              _buildTextField(
                controller: nameController,
                hint: "Enter your name",
                label: "name",
                borderColor: themeColor,
              ),
              SizedBox(height: 15.h),

              _buildLabel("Email"),
              _buildTextField(
                controller: emailController,
                hint: "Enter your email",
                label: "email",
                keyboardType: TextInputType.emailAddress,
                borderColor: themeColor,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter email';
                  }
                  final emailRegex = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
                  if (!emailRegex.hasMatch(value.trim())) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
              SizedBox(height: 15.h),

              _buildLabel("Password"),
              _buildTextField(
                controller: passwordController,
                hint: "Enter password",
                label: "password",
                obscure: true,
                borderColor: themeColor,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter password';
                  }
                  if (value.trim().length < 6) {
                    return 'Password must be at least 6 characters';
                  }
                  return null;
                },
              ),
              SizedBox(height: 15.h),

              _buildLabel("Phone"),
              _buildTextField(
                maxLength: 10,
                controller: phoneController,
                hint: "Enter phone number",
                label: "phone number",
                keyboardType: TextInputType.phone,
                borderColor: themeColor,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter phone number';
                  }
                  if (value.trim().length < 10) {
                    return 'Phone number must be at least 10 digits';
                  }
                  if (!RegExp(r'^\d+$').hasMatch(value.trim())) {
                    return 'Phone number must contain only digits';
                  }
                  return null;
                },
              ),

              SizedBox(height: 15.h),
              if (widget.title.toUpperCase() == "REAL ESTATE") ...[


                _buildLabel("Role"),
                buildDropDown(

                  hint: "Role",
                  items: roleList,
                  onChange: (value) {
                    setState(() {
                      listRole = value;
                    });
                  },
                ),


                SizedBox(height: 15.h),

              ],
              SizedBox(height: 15.h),
            if (widget.title.toUpperCase() == "MATRIMONY") ...[


              _buildLabel("Age"),
              _buildTextField(
                keyboardType: TextInputType.number,
                controller: ageController,
                hint: "Age",
                label: "Age",
                borderColor: themeColor,
              ),
              SizedBox(height: 15.h),

              _buildLabel("Gender"),
              buildDropDown(
                hint: "Select Gender",
                items: genderList,
                onChange: (value) {
                  setState(() {
                    listGender = value;
                  });
                },
              ),

              SizedBox(height: 15.h),

              _buildLabel("Date of Birth"),


              buildDatePickerField(dobController, "date of birth"),
              SizedBox(height: 30.h),
],



              if (widget.title.toUpperCase() == "JOBS") ...[
                _buildLabel("Upload Resume (Image or Document)"),
                SizedBox(height: 8.h),
                GestureDetector(
                  onTap: _pickFile,  // Changed to pickFile
                  child: Container(
                    width: double.infinity,
                    height: 150.h,
                    decoration: BoxDecoration(
                      border: Border.all(color: themeColor, width: 1.5.w),
                      borderRadius: BorderRadius.circular(15.r),
                    ),
                    child: _selectedFile == null
                        ? Center(
                      child: Text(
                        "Tap to select resume (Image or Document)",
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                        : ClipRRect(
                      borderRadius: BorderRadius.circular(15.r),
                      child: _selectedFile is File
                          ? _getFilePreview(_selectedFile!)  // Use a helper method to display the file preview
                          : Center(
                        child: Text(
                          "Selected file: ${_selectedFile?.path.split('/').last}",
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 15.h),
              ],

              GestureDetector(
                onTap: () async {

                  if (_formKey.currentState?.validate() ?? false) {
                    setState(() => _buttonLoader = true);

                    try {
                      if ( widget.title.toUpperCase() == "JOBS") {
                        if (_selectedFile == null) {
                          // If no file is selected, show an error message
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text("Please select a resume (Image or Document)"),
                              backgroundColor: Colors.red,
                            ),
                          );
                          return; // Exit the method to prevent further execution
                        }
                        await Auth.registerJobSeeker(
                          name: nameController.text.trim(),
                          email: emailController.text.trim(),
                          password: passwordController.text.trim(),
                          phone: phoneController.text.trim(),
                          resumeFile: _selectedFile!, // This is a File object
                          context: context,
                        );
                        // Navigation already handled in Auth.registerJobSeeker
                      }
                     else if ( widget.title.toUpperCase() == "REAL ESTATE") {
                        await Auth.registerRealState(
                         nameController.text.trim(),
                         emailController.text.trim(),
                         passwordController.text.trim(),
                         phoneController.text.trim(),
                          listRole.toString(),
                          // resumeFile: _selectedImage!, // This is a File object
                        context,
                        );

                      }
                      else {
                        await Auth.register(
                          emailController.text,
                          passwordController.text,
                          nameController.text,
                          phoneController.text,
                          ageController.text,
                          listGender.toString(),
                          dobController.text,
                          context,
                        );
                      }
                    } catch (e) {
                      // ScaffoldMessenger.of(context).showSnackBar(
                      //   SnackBar(content: Text("Error: ${e.toString()}")),
                      // );
                    } finally {
                      if (mounted) setState(() => _buttonLoader = false);
                    }
                  }
                },
                child: Center(
                  child: Container(
                    width: double.infinity,
                    height: 53.h,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15.r),
                      color: themeColor,
                    ),
                    child: Center(
                      child: _buttonLoader
                          ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                          : Text(
                        'Register',
                        style: GoogleFonts.gothicA1(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                          
                        ),
                      ),
                    ),
                  ),
                ),
              )
,
              SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Already have Account? Login ",
                      style: GoogleFonts.gothicA1(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String label) {
    return Text(
      label,
      style: GoogleFonts.gothicA1(
        fontSize: 16.sp,
        fontWeight: FontWeight.w500,
        color: const Color(0xFF030016),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required Color borderColor,
    String? hint,
    bool obscure = false,
    TextInputType keyboardType = TextInputType.text,
    int? maxLength,
    String? Function(String?)? validator,
  }) {
    OutlineInputBorder customBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(15.r),
      borderSide: BorderSide(color: borderColor, width: 1.5.w),
    );

    return TextFormField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      maxLength: maxLength,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
        hintText: hint,
        hintStyle: GoogleFonts.gothicA1(color: Colors.grey, fontSize: 14.sp),
        enabledBorder: customBorder,
        focusedBorder: customBorder,
        errorBorder: customBorder,
        focusedErrorBorder: customBorder,
        disabledBorder: customBorder,
        counterText: '', // hide character counter
      ),
      validator: validator ??
              (value) {
            if (value == null || value.trim().isEmpty) {
              return 'Please enter $label';
            }
            return null;
          },
    );


  }

  Color _getThemeColor(String title) {
    switch (title.toUpperCase()) {
      case "MATRIMONY":
        return const Color(0xFF97144d);
      case "JOBS":
        return const Color(0xFF0A66C2);
      case "REAL ESTATE":
        return const Color(0xFF00796B);
      default:
        return const Color(0xFF97144d);
    }
  }


/*

  Widget buildDatePickerField(TextEditingController controller, String hint) {
    return TextField(
      controller: controller,
      readOnly: true, // Prevent manual typing
      decoration: InputDecoration(

        hintText: hint,
        contentPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 12.h),
        border: OutlineInputBorder(

          borderRadius: BorderRadius.circular(12.r),
        ),
        suffixIcon: const Icon(Icons.calendar_today),
      ),
      onTap: () async {
        final DateTime? pickedDate = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(1900), // Only allow dates after today
          lastDate: DateTime(2100),
        );

        if (pickedDate != null) {
          // Format date to e.g. 2025-06-30
          final formattedDate = "${pickedDate.year}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.day.toString().padLeft(2, '0')}";
          controller.text = formattedDate;
        }
      },
    );
  }*/

  Widget buildDatePickerField(TextEditingController controller, String hint) {
    return TextField(
      controller: controller,
      readOnly: true, // Prevent manual typing
      decoration: InputDecoration(
        hintText: hint,
        contentPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 12.h),
        suffixIcon: const Icon(Icons.calendar_today),

        // Border when not focused
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.r),
          borderSide: BorderSide(
            color:_getThemeColor(widget.title),
            width: 1.5,
          ),
        ),

        // Border when focused
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.r),
          borderSide: BorderSide(
            color:_getThemeColor(widget.title),
            width: 2.0,
          ),
        ),

        // Optional: default border for consistency
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.r),
          borderSide: BorderSide(
            color:_getThemeColor(widget.title),
          ),
        ),
      ),
      onTap: () async {
        final DateTime? pickedDate = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(1900),
          lastDate: DateTime(2100),
        );

        if (pickedDate != null) {
          final formattedDate = "${pickedDate.year}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.day.toString().padLeft(2, '0')}";
          controller.text = formattedDate;
        }
      },
    );
  }



}

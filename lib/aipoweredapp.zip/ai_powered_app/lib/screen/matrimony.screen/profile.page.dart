


import 'package:ai_powered_app/screen/matrimony.screen/start.page.dart';
import 'package:ai_powered_app/screen/matrimony.screen/upload.photo.page.dart';
import 'package:ai_powered_app/data/providers/profileGetDataProvider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
final genderProvider = StateProvider<String?>((ref) => null);
final religionProvider = StateProvider<String?>((ref) => null);
final castProvider = StateProvider<String?>((ref) => null);
final maritalProvider = StateProvider<String?>((ref) => null);
final nameControllerProvider = Provider.autoDispose<TextEditingController>((ref) => TextEditingController());
final dobControllerProvider = Provider.autoDispose<TextEditingController>((ref) => TextEditingController());
class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(profileDataProvider);
    final nameController = ref.watch(nameControllerProvider);
    final dobController = ref.watch(dobControllerProvider);
    final gender = ref.watch(genderProvider);
    final religion = ref.watch(religionProvider);
    final cast = ref.watch(castProvider);
    final marital = ref.watch(maritalProvider);
    final genderList = ["male", "female", "other"];
    final religionList = [ "Hindu", "Muslim", "Sikh"];
    final castList = [
      "General",
      "OBC",
      "SC",
      "ST",
      "Brahmin",
      "Kshatriya/Rajput",
      "Vaishya/Baniya",
      "Jat",
      "Patel",
      "Yadav",
      "Kori",
      "Kumhar",
      "Kashyap",
      "Khatri",
      "Lohar",
      "Maratha",
      "Sindhi",
      "Sonar",
      "Teli",
      // और “Other”
      "Other"
    ];

    final maritalList = [
      "Doesn't Matter",
      "Never Married",
      "Divorced",
      "Widowed",
      "Awaiting Divorce",
      "Annulled",
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFDF6F8),
      appBar: AppBar(backgroundColor: const Color(0xFFFDF6F8)),
      body: profileAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (profile) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (nameController.text.isEmpty) {
              nameController.text = profile.data.profile.name ?? '';
              dobController.text = profile.data.profile.dateOfBirth.toString().split(" ")[0];
              ref.read(genderProvider.notifier).state = profile.data.profile.gender;
              ref.read(religionProvider.notifier).state = profile.data.profile.religion;
              ref.read(castProvider.notifier).state = profile.data.profile.caste;
              ref.read(maritalProvider.notifier).state = profile.data.profile.maritalStatus;
            }
          });
          return SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 15.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Column(
                   crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,

                  children: [


                  Text(
                    "Basic Details",
                    style: GoogleFonts.gothicA1(
                      fontSize: 30.sp,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF030016),
                      
                    ),
                  ),
                  Text(
                    "Let's Start with the Basics",
                    style: GoogleFonts.gothicA1(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w400,
                      color: const Color(0xFF9A97AE),
                    ),
                  ),
                ],),

                    GestureDetector(
                      onTap: () async {
                        final box = await Hive.openBox('userdata');
                        await box.clear(); // Clear saved user data
                        if (context.mounted) {
                          Navigator.pushReplacement(
                            context,
                            CupertinoPageRoute(builder: (_) => const StartPage()),
                          );
                        }
                      },
                      child: Container(
                        width: 103.w,
                        height: 53.h,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15.r),
                          color: const Color(0xFF97144d),
                        ),
                        child: Center(
                          child: Text(
                            "Logout",
                            style: GoogleFonts.gothicA1(
                              fontSize: 18.sp,
                              fontWeight: FontWeight.w500,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),



                  ],),

                SizedBox(height: 26.h),
                TextField(
                  controller: nameController,
                  decoration: _inputDecoration("Enter your full name"),
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Select Gender",
                  items: genderList,
                  value: gender,
                  onChange: (value) => ref.read(genderProvider.notifier).state = value,
                ),
                SizedBox(height: 15.h),
                TextField(
                  controller: dobController,
                  decoration: _inputDecoration("Enter your Date of Birth"),
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Select Religion",
                  items: religionList,
                  value: religion,
                  onChange: (value) => ref.read(religionProvider.notifier).state = value,
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Select Cast",
                  items: castList,
                  value: cast,
                  onChange: (value) => ref.read(castProvider.notifier).state = value,
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Select Marital Status",
                  items: maritalList,
                  value: marital,
                  onChange: (value) => ref.read(maritalProvider.notifier).state = value,
                ),
                SizedBox(height: 25.h),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      CupertinoPageRoute(builder: (_) => const UploadPhotoPage()),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    height: 53.h,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15.r),
                      color: const Color(0xFF97144d),
                    ),
                    child: Center(
                      child: Text(
                        "Continue",
                        style: GoogleFonts.gothicA1(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  InputDecoration _inputDecoration(String hintText) {
    return InputDecoration(
      contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15.r),
        borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15.r),
        borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
      ),
      hintText: hintText,
      hintStyle: GoogleFonts.gothicA1(
        fontSize: 16.sp,
        fontWeight: FontWeight.w400,
        color: const Color(0xFF030016),
        letterSpacing: -0.2,
      ),
    );
  }
}

class buildDropDown extends StatelessWidget {
  final String hint;
  final List<String> items;
  final String? value;
  final Function(String?) onChange;

  const buildDropDown({
    super.key,
    required this.hint,
    required this.items,
    this.value,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      icon: const Icon(Icons.keyboard_arrow_down),
      value: (value != null && items.contains(value)) ? value : null,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        hintText: hint,
        hintStyle: GoogleFonts.gothicA1(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          color: const Color(0xFF030016),
          letterSpacing: -0.2,
        ),
      ),
      items: items.map((item) {
        return DropdownMenuItem(
          value: item,
          child: Text(
            item,
            style: GoogleFonts.gothicA1(
              fontSize: 16.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF030016),
              letterSpacing: -0.2,
            ),
          ),
        );
      }).toList(),
      onChanged: onChange,
    );
  }
}

import 'package:ai_powered_app/screen/matrimony.screen/interest.page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../data/providers/profileGetDataProvider.dart';

final countryProvider = StateProvider<String?>((ref) => null);
final statelistProvider = StateProvider<String?>((ref) => null);
final citylistProvider = StateProvider<String?>((ref) => null);
final livingStatuslistProvider = StateProvider<String?>((ref) => null);
final dietlistProvider = StateProvider<String?>((ref) => null);
final smokinglistProvider = StateProvider<String?>((ref) => null);
final drinkinglistProvider = StateProvider<String?>((ref) => null);



class LocationLifestylePage extends ConsumerWidget {
  const LocationLifestylePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(profileDataProvider);
    final country = ref.watch(countryProvider);
    final state = ref.watch(statelistProvider);
    final city = ref.watch(citylistProvider);
    final livingStatus = ref.watch(livingStatuslistProvider);
    final diet = ref.watch(dietlistProvider);
    final smoking = ref.watch(smokinglistProvider);
    final drinking = ref.watch(drinkinglistProvider);
    final countrylist = ["India","USA", "Canada"];
    final statelist = ["Delhi", "Rajasthan", "Bihar"];
    final citylist = ["New Delhi",  "Jaipur", "Siwan"];
    final livingStatuslist = ["With Parents",  "Alone", "With Roommates"];
    final dietlist = ["Vegetarian", "Non-vegetarian", "Both"];
    final smokinglist = ["Yes", "No","Occasionally"];
    final drinkinglist = ["Yes", "No", "Occasionally"];
    return Scaffold(
      backgroundColor: const Color(0xFFFDF6F8),
      appBar: AppBar(backgroundColor: const Color(0xFFFDF6F8)),
      body: profileAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (profile) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (ref.read(countryProvider) == null) {
              ref.read(countryProvider.notifier).state =
              profile.data.profile.country;
              ref.read(statelistProvider.notifier).state =
                  profile.data.profile.state;
              ref.read(citylistProvider.notifier).state =
                 profile.data.profile.city;
              ref.read(livingStatuslistProvider.notifier).state =
                 profile.data.profile.livingStatus;
              ref.read(dietlistProvider.notifier).state =
                 profile.data.profile.drink;
              ref.read(smokinglistProvider.notifier).state =
               profile.data.profile.smoke;
              ref.read(drinkinglistProvider.notifier).state =
                 profile.data.profile.drink;
            }
          });

          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 15.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Location & Lifestyle",
                  style: GoogleFonts.gothicA1(
                    fontSize: 30.sp,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF030016),
                    
                  ),
                ),
                Text(
                  "Where Do You Live?",
                  style: GoogleFonts.gothicA1(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
                    color: const Color(0xFF9A97AE),
                  ),
                ),
                SizedBox(height: 25.h),
                buildDropDown(
                  hint: "Select Country",
                  items: countrylist,
                  value: countrylist.contains(country) ? country : null,
                  onChange: (value) {
                    print("Selected Country: $value");
                    ref.read(countryProvider.notifier).state = value;
                  },
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Select State",
                  items: statelist,
                  value: statelist.contains(state) ? state : null,
                  onChange: (value) {
                    print("Selected state: $value");
                    ref.read(statelistProvider.notifier).state = value;
                  },
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Select City",
                  items: citylist,
                  value: citylist.contains(city) ? city : null,
                  onChange: (value) => ref.read(citylistProvider.notifier).state = value,
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Select Living Status",
                  items: livingStatuslist,
                  value: livingStatuslist.contains(livingStatus) ? livingStatus : null,
                  onChange: (value) => ref.read(livingStatuslistProvider.notifier).state = value,
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Do you Smoke?",
                  items: smokinglist,
                  value: smokinglist.contains(smoking) ? smoking : null,
                  onChange: (value) => ref.read(smokinglistProvider.notifier).state = value,
                ),
                SizedBox(height: 15.h),
                buildDropDown(
                  hint: "Do you Drink?",
                  items: drinkinglist,
                  value: drinkinglist.contains(drinking) ? drinking : null,
                  onChange: (value) => ref.read(drinkinglistProvider.notifier).state = value,
                ),
                SizedBox(height: 15.h),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      CupertinoPageRoute(builder: (_) => const InterestPage()),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    height: 53.h,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15.r),
                      color: const Color(0xFF97144d),
                    ),
                    child: Center(
                      child: Text(
                        "Continue",
                        style: GoogleFonts.gothicA1(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // Custom dropdown widget
  Widget buildDropDown({
    required String hint,
    required List<String> items,
    required String? value,
    required Function(String?) onChange,
  }) {
    return DropdownButtonFormField<String>(
      icon: const Icon(Icons.keyboard_arrow_down),
      value: value,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.w),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15.r),
          borderSide: BorderSide(color: const Color(0xFFDADADA), width: 1.5.w),
        ),
        hintText: hint,
        hintStyle: GoogleFonts.gothicA1(
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,
          color: const Color(0xFF030016),
        ),
      ),
      items: items.map((item) {
        return DropdownMenuItem(
          value: item,
          child: Text(
            item,
            style: GoogleFonts.gothicA1(
              fontSize: 16.sp,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF030016),
            ),
          ),
        );
      }).toList(),
      onChanged: onChange,
    );
  }

}



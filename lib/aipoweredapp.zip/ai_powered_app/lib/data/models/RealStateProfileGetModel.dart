// To parse this JSON data, do
//
//     final realStateProfileGetModel = realStateProfileGetModelFromJson(jsonString);

import 'dart:convert';

RealStateProfileGetModel realStateProfileGetModelFromJson(String str) => RealStateProfileGetModel.fromJson(json.decode(str));

String realStateProfileGetModelToJson(RealStateProfileGetModel data) => json.encode(data.toJson());

class RealStateProfileGetModel {
  bool? success;
  Data? data;

  RealStateProfileGetModel({
    this.success,
    this.data,
  });

  factory RealStateProfileGetModel.fromJson(Map<String, dynamic> json) => RealStateProfileGetModel(
    success: json["success"],
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "data": data?.toJson(),
  };
}

class Data {
  int? id;
  String? name;
  String? email;
  String? phone;
  String? role;
  DateTime? createdAt;
  DateTime? updatedAt;

  Data({
    this.id,
    this.name,
    this.email,
    this.phone,
    this.role,
    this.createdAt,
    this.updatedAt,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    role: json["role"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "phone": phone,
    "role": role,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}

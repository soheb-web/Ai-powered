import 'package:flutter_riverpod/flutter_riverpod.dart';

final selectedInterestProvider = StateProvider<String>((ref) => '');
